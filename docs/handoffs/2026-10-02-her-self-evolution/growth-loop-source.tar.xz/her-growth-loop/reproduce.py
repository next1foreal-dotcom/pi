#!/usr/bin/env python3
"""Run this candidate's offline engineering tests; never install deps or touch a user checkout."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True, help="A new output directory")
    parser.add_argument("--type-roots", type=Path, help="Directory containing @types/node")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    args.out.mkdir(parents=True, exist_ok=False)
    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    for name, expected in manifest["new_source_files"].items():
        data = (root / "source" / name).read_bytes()
        if hashlib.sha256(data).hexdigest() != expected:
            raise RuntimeError(f"Source digest mismatch: {name}")
    environment = {k: v for k, v in os.environ.items()
                   if k.upper() in {"PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "TMPDIR"}}
    commands = []
    def run(argv, filename):
        result = subprocess.run(argv, cwd=root, env=environment, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=60)
        log = args.out / filename
        log.write_text(result.stdout, encoding="utf-8")
        commands.append({"argv": argv, "cwd": str(root), "exit_code": result.returncode,
                         "log": filename, "sha256": hashlib.sha256(log.read_bytes()).hexdigest()})
        return result.returncode
    node = shutil.which("node")
    if not node:
        raise RuntimeError("Node is required. No dependency was installed.")
    code = run([node, "--experimental-strip-types", "--test", "--test-reporter=tap",
                "source/packages/her/test/growth-experiment.test.ts"], "tests.tap")
    print(f"Engineering tests exit: {code}")
    tsc = shutil.which("tsc")
    types = args.type_roots
    if types is None and tsc:
        global_root = Path(tsc).resolve().parents[2]
        candidate = global_root / "ts-node" / "node_modules" / "@types"
        if (candidate / "node" / "package.json").exists():
            types = candidate
    if tsc and types and (types / "node" / "package.json").exists():
        files = sorted(str(p.relative_to(root)) for p in (root / "source").rglob("*.ts"))
        type_code = run([tsc, "--noEmit", "--strict", "--noUnusedLocals", "--noUnusedParameters",
                        "--target", "ES2022", "--module", "NodeNext", "--moduleResolution", "NodeNext",
                        "--allowImportingTsExtensions", "--types", "node", "--typeRoots", str(types),
                        *files], "typecheck.log")
        print(f"Local strict typecheck exit: {type_code}")
        code = code or type_code
    else:
        print("Local typecheck NOT RUN: supply installed tsc and --type-roots. No installation attempted.")
        code = code or 2
    (args.out / "commands.json").write_text(json.dumps(commands, indent=2), encoding="utf-8")
    print("These are scripted engineering fixtures, not a real-agent learning experiment.")
    return code

if __name__ == "__main__":
    sys.exit(main())
